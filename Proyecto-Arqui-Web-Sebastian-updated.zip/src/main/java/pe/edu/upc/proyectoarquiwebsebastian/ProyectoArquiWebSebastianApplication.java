package pe.edu.upc.proyectoarquiwebsebastian;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoArquiWebSebastianApplication {
    public static void main(String[] args) {
        SpringApplication.run(ProyectoArquiWebSebastianApplication.class, args);
    }
}