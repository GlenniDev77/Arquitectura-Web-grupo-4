package pe.edu.upc.proyectoarquiwebsebastian.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import pe.edu.upc.proyectoarquiwebsebastian.dto.AntiguedadUltimoDelitoDTO;
import pe.edu.upc.proyectoarquiwebsebastian.repositories.DelitoRepository;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/delitos")
public class DelitoController {

    private final DelitoRepository delitoRepository;

    @Autowired
    public DelitoController(DelitoRepository delitoRepository) {
        this.delitoRepository = delitoRepository;
    }

    @GetMapping("/antiguedad-ultimo-por-zona")
    public List<AntiguedadUltimoDelitoDTO> antiguedadUltimoDelitoPorZona() {
        List<Object[]> resultados = delitoRepository.antiguedadUltimoDelitoPorZona();
        List<AntiguedadUltimoDelitoDTO> dtos = new ArrayList<>();
        for (Object[] fila : resultados) {
            String zona = (String) fila[0];
            Timestamp ts = (Timestamp) fila[1];
            LocalDateTime ultimo = ts != null ? ts.toLocalDateTime() : null;
            int dias = fila[2] != null ? ((Number) fila[2]).intValue() : 0;
            dtos.add(new AntiguedadUltimoDelitoDTO(zona, ultimo, dias));
        }
        return dtos;
    }
}