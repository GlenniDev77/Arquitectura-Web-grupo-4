package pe.edu.upc.proyectoarquiwebsebastian.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

/**
 * Entidad para la tabla ZONA.
 */
@Entity
@Table(name = "Zona")
public class Zona {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_zona")
    private int idZona;

    @Column(name = "nombre", nullable = false)
    private String nombre;

    @Column(name = "distrito")
    private String distrito;

    @Column(name = "EstadoZona")
    private String estadoZona;

    @Column(name = "latitud")
    private Double latitud;

    @Column(name = "longitud")
    private Double longitud;

    public Zona() {
    }

    public Zona(int idZona, String nombre, String distrito, String estadoZona, Double latitud, Double longitud) {
        this.idZona = idZona;
        this.nombre = nombre;
        this.distrito = distrito;
        this.estadoZona = estadoZona;
        this.latitud = latitud;
        this.longitud = longitud;
    }

    public int getIdZona() {
        return idZona;
    }

    public void setIdZona(int idZona) {
        this.idZona = idZona;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getDistrito() {
        return distrito;
    }

    public void setDistrito(String distrito) {
        this.distrito = distrito;
    }

    public String getEstadoZona() {
        return estadoZona;
    }

    public void setEstadoZona(String estadoZona) {
        this.estadoZona = estadoZona;
    }

    public Double getLatitud() {
        return latitud;
    }

    public void setLatitud(Double latitud) {
        this.latitud = latitud;
    }

    public Double getLongitud() {
        return longitud;
    }

    public void setLongitud(Double longitud) {
        this.longitud = longitud;
    }
}