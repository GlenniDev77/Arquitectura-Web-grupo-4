package pe.edu.upc.proyectoarquiwebsebastian.repositories;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import pe.edu.upc.proyectoarquiwebsebastian.entities.Delito;

import java.util.List;

@Repository
public interface DelitoRepository extends JpaRepository<Delito, Integer> {

    @Query(value = """
            SELECT z.nombre AS zona,
                   MAX(d.fecha_hora) AS ultimo_delito,
                   EXTRACT(DAY FROM (CURRENT_DATE - MAX(d.fecha_hora)))::int AS dias_desde_ultimo
            FROM Delito d
            JOIN Zona z ON d.id_zona = z.id_zona
            GROUP BY z.nombre
            ORDER BY dias_desde_ultimo DESC
            """,
            nativeQuery = true)
    List<Object[]> antiguedadUltimoDelitoPorZona();
}