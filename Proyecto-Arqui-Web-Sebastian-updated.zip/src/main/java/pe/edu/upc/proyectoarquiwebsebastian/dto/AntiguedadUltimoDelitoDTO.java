package pe.edu.upc.proyectoarquiwebsebastian.dto;

import java.time.LocalDateTime;

/**
 * Representa la información necesaria para devolver la antigüedad del último delito por zona.
 */
public class AntiguedadUltimoDelitoDTO {
    private String zona;
    private LocalDateTime ultimoDelito;
    private int diasDesdeUltimo;

    public AntiguedadUltimoDelitoDTO() {
    }

    public AntiguedadUltimoDelitoDTO(String zona, LocalDateTime ultimoDelito, int diasDesdeUltimo) {
        this.zona = zona;
        this.ultimoDelito = ultimoDelito;
        this.diasDesdeUltimo = diasDesdeUltimo;
    }

    public String getZona() {
        return zona;
    }

    public void setZona(String zona) {
        this.zona = zona;
    }

    public LocalDateTime getUltimoDelito() {
        return ultimoDelito;
    }

    public void setUltimoDelito(LocalDateTime ultimoDelito) {
        this.ultimoDelito = ultimoDelito;
    }

    public int getDiasDesdeUltimo() {
        return diasDesdeUltimo;
    }

    public void setDiasDesdeUltimo(int diasDesdeUltimo) {
        this.diasDesdeUltimo = diasDesdeUltimo;
    }
}