package pe.edu.upc.proyectoarquiwebsebastian.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.time.LocalDateTime;

/**
 * Entidad para la tabla DELITO.
 */
@Entity
@Table(name = "Delito")
public class Delito {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_reportedelito")
    private int idReporteDelito;

    @ManyToOne
    @JoinColumn(name = "id_zona", nullable = false)
    private Zona zona;

    @Column(name = "fecha_hora", nullable = false)
    private LocalDateTime fechaHora;

    @Column(name = "tipo_delito")
    private String tipoDelito;

    @Column(name = "descripcion")
    private String descripcion;

    @Column(name = "nombre")
    private String nombre;

    public Delito() {
    }

    public Delito(int idReporteDelito, Zona zona, LocalDateTime fechaHora, String tipoDelito, String descripcion, String nombre) {
        this.idReporteDelito = idReporteDelito;
        this.zona = zona;
        this.fechaHora = fechaHora;
        this.tipoDelito = tipoDelito;
        this.descripcion = descripcion;
        this.nombre = nombre;
    }

    public int getIdReporteDelito() {
        return idReporteDelito;
    }

    public void setIdReporteDelito(int idReporteDelito) {
        this.idReporteDelito = idReporteDelito;
    }

    public Zona getZona() {
        return zona;
    }

    public void setZona(Zona zona) {
        this.zona = zona;
    }

    public LocalDateTime getFechaHora() {
        return fechaHora;
    }

    public void setFechaHora(LocalDateTime fechaHora) {
        this.fechaHora = fechaHora;
    }

    public String getTipoDelito() {
        return tipoDelito;
    }

    public void setTipoDelito(String tipoDelito) {
        this.tipoDelito = tipoDelito;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}